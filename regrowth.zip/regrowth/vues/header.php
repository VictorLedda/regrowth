<header>
        <nav>
            <div>
                <img src='images/lotus.JPG'>
            </div>
            <div id='menu'>
                <a href='./index.php'> accueil </a>
                <a href='./articles.php'> articles </a>
                <a href=''> interview </a>
                <a href='./contact.php'> contact </a>
            </div>
        </nav>
    </header>