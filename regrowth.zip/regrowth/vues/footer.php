<footer>
        <div id='mail'>
            <p> Contactez-nous :</p>
            <a href="mailto:regrowthptut@gmail.com"> regrowthptut@gmail.com </a>
        </div>

        <div id='reseaux'>
            <p> Suivez-nous sur : </p>
            <a href='#'> facebook </a>
            <a href='https://www.instagram.com/projet_regrowth/'> instagram </a>
            <a href='https://twitter.com/projetRegrowth'> twitter </a>
        </div>
    </footer>